#!/bin/bash
mkdir -p /root/mytool/infogath/$1
echo "what do yous want today"
echo "1 --> DNS Analysis"
echo "2 --> Subdomain Search"
echo "3 --> Nmap Scan"
echo "4 --> Web Server Scan with Nikto"
read -p "entrer un numero du 1 a 4 " option
if [ "$option" -eq 1 ]; then
dns=$(nslookup -type=A $1)
touch /root/mytool/infogath/$1/dnsenum_result.txt
echo "$dns"
echo "$dns" > /root/mytool/infogath/$1/dnsenum_result.txt
elif [ "$option" -eq 2 ]; then
subdomain=$(subfinder -v -d "$1")
touch /root/mytool/infogath/$1/sublist3r_result.txt
echo "$subdomain"
echo "$subdomain" > /root/mytool/infogath/$1/sublist3r_result.txt
elif [ "$option" -eq 3 ]; then
echo "attend un peu que le scann se termine "
nmap $1
scan=$(nmap $1)
touch /root/mytool/infogath/$1/nmap_result.txt
echo "$scan"
echo "$scan" > /root/mytool/infogath/$1/nmap_result.txt
elif [ "$option" -eq 4 ]; then
nikto -h $1
nikt=$(nikto -h $1)
touch /root/mytool/infogath/$1/nikto_result.txt
echo "$nikt"
echo "$nikt" > /root/mytool/infogath/$1/nikto_result.txt




else
    echo "Le nombre est inférieur à 10."
fi
